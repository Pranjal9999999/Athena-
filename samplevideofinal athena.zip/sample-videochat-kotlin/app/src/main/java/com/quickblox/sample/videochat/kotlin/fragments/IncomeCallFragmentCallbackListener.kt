package com.quickblox.sample.videochat.kotlin.fragments


interface IncomeCallFragmentCallbackListener {

    fun onAcceptCurrentSession()

    fun onRejectCurrentSession()
}