package com.quickblox.sample.videochat.kotlin.fragments


interface OnCallEventsController {

    fun onUseHeadSet(use: Boolean)
}